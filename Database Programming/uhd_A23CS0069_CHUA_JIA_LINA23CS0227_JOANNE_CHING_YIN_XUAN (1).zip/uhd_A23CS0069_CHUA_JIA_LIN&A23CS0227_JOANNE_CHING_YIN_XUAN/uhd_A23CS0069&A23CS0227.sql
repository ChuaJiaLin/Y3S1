/*
Student: Chua Jia Lin, Joanne Ching Yin Xuan
Matric no: A23CS0069, A23CS0227
*/

/*Task 1: Database Creation and Integrity Constraints*/
DROP DATABASE IF EXISTS hostel_mgmt_chua_joanne;
CREATE SCHEMA `hostel_mgmt_chua_joanne` ;
USE hostel_mgmt_chua_joanne;

/*Table 1 – room_types*/
CREATE TABLE room_types (
	type_id INT AUTO_INCREMENT PRIMARY KEY,
	type_name VARCHAR(20) UNIQUE NOT NULL,
	rent DECIMAL(10,2) NOT NULL,
	deposit DECIMAL(10,2) NOT NULL,
	capacity INT NOT NULL
);

/*Table 2 – rooms*/
CREATE TABLE rooms (
	room_id INT AUTO_INCREMENT PRIMARY KEY,
	type_id INT NOT NULL,
	room_no VARCHAR(10) NOT NULL UNIQUE,
	floor_no INT NOT NULL,
	is_occupied ENUM('TRUE','FALSE') NOT NULL,
	FOREIGN KEY (type_id) REFERENCES room_types(type_id)
);

/*Table 3 – students*/
CREATE TABLE students (
	student_id INT AUTO_INCREMENT PRIMARY KEY,
	room_id INT NOT NULL,
	fname VARCHAR(30) NOT NULL,
	lname VARCHAR(30) NOT NULL,
	status ENUM('ACTIVE','NON_ACTIVE') NOT NULL,
	checkin_date DATE NOT NULL,
	FOREIGN KEY (room_id) REFERENCES rooms(room_id)
);

/*Table 4 – maintenance*/
CREATE TABLE maintenance (
	maint_id INT AUTO_INCREMENT PRIMARY KEY,
	room_id INT NOT NULL,
	issue_desc VARCHAR(255) NOT NULL,
	severity ENUM('LOW','MEDIUM','HIGH') NOT NULL,
	status ENUM('OPEN','RESOLVED') NOT NULL,
	reported_on DATE NOT NULL,
	resolved_on DATE,
	FOREIGN KEY (room_id) REFERENCES rooms(room_id)
);

/*Table 5 – payments*/
CREATE TABLE payments (
	payment_id INT AUTO_INCREMENT PRIMARY KEY,
	student_id INT NOT NULL,
	amount DECIMAL(10,2) NOT NULL,
	paid_on DATE NOT NULL,
	method ENUM('CASH','FPX','CARD','TNG') NOT NULL,
	note VARCHAR(255),
	FOREIGN KEY (student_id) REFERENCES students(student_id)
);

SHOW TABLES;

/* A room is ‘occupied’ if it has ≥1 student with 
status='ACTIVE'; otherwise 'VACANT'*/
UPDATE rooms 
	SET is_occupied= (
		CASE
			WHEN room_id IN (
				SELECT room_id
                FROM students
                WHERE status='ACTIVE'
            )
            THEN 'TRUE'
            ELSE 'FALSE'
		END
    );
    
SELECT room_id, room_no, is_occupied FROM rooms;

/*Demonstrate schema maintenance*/ 
/*ALTER TABLE: add an email column to students and mark it UNIQUE.*/
ALTER TABLE students
	ADD email VARCHAR(50) UNIQUE NOT NULL;
SHOW COLUMNS FROM students;

/*DROP TABLE: create a temporary test table and drop it safely. */
CREATE TABLE temp_test (
	id INT PRIMARY KEY
);
/*Show table that after temp_test creation*/
SHOW TABLES;

DROP TABLE temp_test;

/*Show table that after temp_test deletion*/
SHOW TABLES;

/*Task 2: Data Manipulation and Filtering */

/*Data Insertion (DML)*/
INSERT INTO room_types (type_id,type_name,rent,deposit,capacity) VALUES
	(1,'Single',300.00,150.00,1),
    (2,'Double',200.00,100.00,2),
    (3,'Premium',400.00,200.00,1),
    (4,'Family',600.00,300.00,4);
SELECT * FROM room_types;
    
/*F1 have single,double; F2 have premium; F3 have family; 
  block a&b for female; block c for male*/
INSERT INTO rooms (room_id,room_no,floor_no,is_occupied,type_id) VALUES
	(1,'A101',1,'FALSE',1),
    (2,'A102',1,'FALSE',2),
    (3,'A201',2,'FALSE',3),
    (4,'A301',3,'FALSE',4),
    (5,'B101',1,'FALSE',1),
    (6,'B102',1,'FALSE',2),
    (7,'B201',2,'FALSE',3),
    (8,'B301',3,'FALSE',4),
    (9,'C101',1,'FALSE',1),
    (10,'C102',1,'FALSE',2),
    (11,'C201',2,'FALSE',3),
    (12,'C301',3,'FALSE',4);
SELECT * FROM rooms;
    
/*1-12 is female; 13-20 is male*/    
INSERT INTO students (student_id,fname,lname,status,checkin_date,email,room_id) VALUES
	(1,'Alice','Chua','NON_ACTIVE','2023-01-01','alicechua1@gmail.com',1),
    (2,'Betty','Ching','NON_ACTIVE','2024-02-01','bettyching2@gmail.com',2),
    (3,'Claire','Tan','ACTIVE','2025-03-01','clairetan3@gmail.com',3),
    (4,'Daisy','Ong','NON_ACTIVE','2023-04-01','daisyong4@gmail.com',4),
    (5,'Emily','Wong','NON_ACTIVE','2024-05-01','emilywong5@yahoo.com',5),
    (6,'Fiona','Lim','ACTIVE','2025-06-01','fionalim6@yahoo.com',6),
    (7,'Grace','Lee','NON_ACTIVE','2023-07-01','gracelee7@yahoo.com',7),
    (8,'Hannah','Lau','ACTIVE','2024-08-01','hannahlau8@yahoo.com',8),
    (9,'Ivy','Tan','NON_ACTIVE','2024-08-01','ivytan9@yahoo.com',1),
    (10,'Jessi','Liew','ACTIVE','2025-09-01','jessiliew10@yahoo.com',2),
    (11,'Kelly','Chio','NON_ACTIVE','2023-10-01','kellychio11@yahoo.com',4),
    (12,'Lily','Chuah','ACTIVE','2024-01-01','lilychuah12@yahoo.com',7),
    (13,'Alex','Neo','NON_ACTIVE','2025-09-01','alexneo13@gmail.com',9),
    (14,'Ben','Chau','NON_ACTIVE','2023-10-01','benchau14@gmail.com',10),
    (15,'Cooper','Ng','ACTIVE','2024-11-01','cooperng15@gmail.com',11),
    (16,'Danny','Chia','NON_ACTIVE','2025-01-01','dannychia16@gmail.com',12),
    (17,'Ethan','Choh','ACTIVE','2023-02-01','ethanchoh17@yahoo.com',9),
    (18,'Felix','Goh','NON_ACTIVE','2024-03-01','felixgoh18@yahoo.com',10),
    (19,'George','Chan','NON_ACTIVE','2025-04-01','georgechan19@yahoo.com',11),
    (20,'Harley','Lim','ACTIVE','2024-08-01','harleylim20@yahoo.com',12);
SELECT * FROM students;   

INSERT INTO maintenance (maint_id,issue_desc,severity,status,reported_on,resolved_on,room_id) VALUES
	(1,'Window handle fell off','LOW','OPEN','2025-07-21',NULL,1),
    (2,'Fan is not functioning well','LOW','OPEN','2024-12-13',NULL,2),
    (3,'Study lamp not functioning','LOW','RESOLVED','2023-01-01','2023-01-31',5),
    (4,'Lamp not functioning','LOW','RESOLVED','2024-09-22','2024-11-02',7),
    (5,'Socket not functioning','MEDIUM','OPEN','2024-11-30',NULL,5),
    (6,'Socket not functioning','MEDIUM','OPEN','2025-06-16',NULL,6),
    (7,'Window cannot close completely','MEDIUM','RESOLVED','2023-01-18','2023-02-20',2),
    (8,'Water leakage in bathroom','HIGH','OPEN','2025-10-28',NULL,9),
    (9,'Water leakage from wall','HIGH','RESOLVED','2025-10-30','2025-10-31',6),
    (10,'Water leakage in bathroom','HIGH','RESOLVED','2024-08-25','2024-09-05',8);
SELECT * FROM maintenance;   

INSERT INTO payments (payment_id,amount,paid_on,method,note,student_id) VALUES
	(1,400.00,'2025-09-21','CASH','September Rent',3),
    (2,200.00,'2025-09-11','CASH','September Rent',6),
    (3,600.00,'2025-09-15','FPX','September Rent',8),
    (4,200.00,'2025-09-03','FPX','September Rent',10),
    (5,400.00,'2025-09-01','CARD','September Rent',12),
    (6,400.00,'2025-09-09','CARD','September Rent',15),
    (7,300.00,'2025-09-25','TNG','September Rent',17),
    (8,600.00,'2025-09-20','TNG','September Rent',20),
    (9,400.00,'2025-10-14','CASH','October Rent',3),
    (10,200.00,'2025-10-22','FPX','October Rent',6);
SELECT * FROM payments;

/*UPDATE and DELETE Operations*/
/*Update the is_occupied to TRUE for rooms with ACTIVE students; 
  otherwise, FALSE. */
UPDATE rooms 
	SET is_occupied= (
		CASE
			WHEN room_id IN (
				SELECT room_id
                FROM students
                WHERE status='ACTIVE'
            )
            THEN 'TRUE'
            ELSE 'FALSE'
		END
    );

SELECT room_id, room_no, is_occupied FROM rooms;

/*Delete RESOLVED maintenance older than 60 days */
DELETE FROM maintenance
WHERE status='RESOLVED' AND (CURRENT_DATE-reported_on)>60;

SELECT * FROM maintenance;

/*Data Retrieval and Filtering Queries*/
/*Rent between 400 and 800*/
SELECT *
FROM room_types
WHERE rent BETWEEN 400 AND 800;


/*Names starting with 'A'*/
SELECT *
FROM students
WHERE fname LIKE 'A%';


/*Payments by FPX or CARD*/
SELECT *
FROM payments
WHERE method IN ('FPX','CARD');

/*Filter room from block a&b(female block) and (room type is single or is not occupied)*/
SELECT *
FROM rooms
WHERE (room_no NOT LIKE 'C%' AND (type_id=1 OR is_occupied='FALSE'));

/*Functions and Expressions*/
/*Aggregate Function: Count ACTIVE students*/
SELECT COUNT(*) AS active_students_count
FROM students
WHERE status='ACTIVE';

/*String Functions: Uppercase full names*/
SELECT UPPER(CONCAT(fname,' ',lname)) AS active_students
FROM students
WHERE status='ACTIVE';


/*Task 3: Reporting and Aggregation*/

/* Create a view v_room_status */
CREATE VIEW v_room_status AS
SELECT room_no,type_name,rent,floor_no,capacity,
COUNT(DISTINCT students.student_id) AS n_occupants,
SUM(CASE 
		WHEN maintenance.status='OPEN' THEN 1 
        ELSE 0 
	END) AS pending_issues,
CASE
	WHEN COUNT(DISTINCT students.student_id)=0 THEN 'TRUE'
    ELSE 'FALSE'
END AS is_vacant
FROM rooms
JOIN room_types ON rooms.type_id=room_types.type_id
LEFT JOIN students ON students.room_id=rooms.room_id AND students.status='ACTIVE'
LEFT JOIN maintenance ON rooms.room_id=maintenance.room_id
GROUP BY rooms.room_id;
/*View data*/
SELECT * FROM v_room_status;

/*Summary queries (for the ≥10-per-table dataset)*/

/*Total number of students per room type*/
SELECT type_name,SUM(CASE WHEN students.status='ACTIVE' THEN 1 ELSE 0 END) AS total_students
FROM room_types
JOIN rooms ON room_types.type_id=rooms.type_id
JOIN students ON rooms.room_id=students.room_id
GROUP BY type_name;

/*Average rent & total deposit per room type*/
SELECT type_name,
ROUND(AVG(rent),2) AS average_rent,
ROUND(SUM(deposit),2) AS total_deposit
FROM room_types
JOIN rooms ON room_types.type_id=rooms.type_id
GROUP BY type_name;

/*Monthly payment totals grouped by year & month*/
SELECT 
	YEAR(paid_on) AS Year,
    MONTH(paid_on) AS Month,
	SUM(amount) AS Monthly_Total
FROM payments
GROUP BY YEAR(paid_on),MONTH(paid_on);

/*OPEN maintenance issues per floor*/
SELECT rooms.floor_no,
	COUNT(maint_id) AS Total_Open_Issue
FROM maintenance
JOIN rooms ON maintenance.room_id=rooms.room_id 
WHERE status='OPEN'
GROUP BY rooms.floor_no
HAVING COUNT(maint_id)>2;

/*SQL functions*/
SELECT 
	UPPER(type_name) AS room_type,
    CONCAT('RM',ROUND(rent,2)) AS rent,
    CONCAT('RM',ROUND(deposit,2)) AS deposit,
    CASE
		WHEN rent<300 THEN 'LOW'
        WHEN rent BETWEEN 300 AND 500 THEN 'MEDIUM'
        ELSE 'HIGH'
	END AS rent_level
FROM room_types
ORDER BY rent;

